# Bookdown

The bookdown package is used to power http://adv-r.had.co.nz
